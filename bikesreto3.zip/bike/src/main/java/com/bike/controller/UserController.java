package com.bike.controller;

import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Map;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMethod;

@RestController
@CrossOrigin("*")
public class UserController {
    
}
