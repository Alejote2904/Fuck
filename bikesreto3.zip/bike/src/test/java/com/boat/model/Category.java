package com.boat.model;

/**
 *
 * @author desaextremo
 */
public class Category {
    
}
